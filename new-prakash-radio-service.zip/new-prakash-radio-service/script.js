/* New Prakash Radio Service website interactions.
   Set SHOP_WHATSAPP to your store's number, country
   code included, digits only (example: 919876543210).
*/
const SHOP_WHATSAPP = ""; // TODO: enter verified shop WhatsApp number

const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];

$("#year").textContent = new Date().getFullYear();

/* Mobile navigation */
const menuToggle = $("#menuToggle");
const nav = $(".nav nav");
menuToggle.addEventListener("click", () => {
  const opened = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(opened));
});
$$(".nav nav a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

/* Page progress */
function updateProgress(){
  const max = document.documentElement.scrollHeight - innerHeight;
  $("#progressBar").style.width = (max > 0 ? scrollY / max * 100 : 0) + "%";
}
addEventListener("scroll", updateProgress, {passive:true});
addEventListener("resize", updateProgress);
updateProgress();

/* Draw an attractive, animated pseudo-globe with land-like dot clusters.
   It is a visual intro, not a geospatial map. */
const canvas = $("#globe");
const ctx = canvas.getContext("2d");
let globeDots = [];
let canvasSize = 800;
function resizeGlobe(){
  const dpr = Math.min(devicePixelRatio || 1, 2);
  const rect = canvas.getBoundingClientRect();
  canvas.width = Math.round(rect.width*dpr);
  canvas.height = Math.round(rect.height*dpr);
  ctx.setTransform(canvas.width/800,0,0,canvas.height/800,0,0);
  canvasSize = 800;
  buildDots();
}
function ellipseContains(lon,lat,cx,cy,rx,ry,rotation=0){
  const a=(lon-cx)*Math.cos(rotation)-(lat-cy)*Math.sin(rotation);
  const b=(lon-cx)*Math.sin(rotation)+(lat-cy)*Math.cos(rotation);
  return (a*a)/(rx*rx)+(b*b)/(ry*ry)<1;
}
function land(lon,lat){
  // Loose recognizable continent-ish clusters, decorative only.
  return ellipseContains(lon,lat,-110,42,48,25,-.5) ||
    ellipseContains(lon,lat,-78,-15,22,43,-.2) ||
    ellipseContains(lon,lat,18,12,27,43,-.1) ||
    ellipseContains(lon,lat,75,43,62,30,-.2) ||
    ellipseContains(lon,lat,135,-25,23,15,.2) ||
    ellipseContains(lon,lat,-42,73,20,10,0);
}
function buildDots(){
  globeDots=[];
  for(let lat=-78;lat<=82;lat+=2.3){
    for(let lon=-178;lon<=178;lon+=2.3){
      if(land(lon,lat))globeDots.push({lon,lat,land:true});
    }
  }
  for(let i=0;i<600;i++)globeDots.push({lon:Math.random()*360-180,lat:Math.random()*150-75,land:false});
}
let rotation=0;
function drawGlobe(){
  const w=800,h=800;
  ctx.clearRect(0,0,w,h);
  const glow=ctx.createRadialGradient(270,230,15,400,400,420);
  glow.addColorStop(0,"rgba(27,116,180,.26)");
  glow.addColorStop(.55,"rgba(5,35,70,.12)");
  glow.addColorStop(1,"rgba(0,0,0,0)");
  ctx.fillStyle=glow;ctx.fillRect(0,0,w,h);
  // Sphere clipping gives a round planet.
  ctx.save();ctx.beginPath();ctx.arc(400,400,390,0,Math.PI*2);ctx.clip();
  ctx.strokeStyle="rgba(81,215,255,.12)";ctx.lineWidth=1;
  for(let r=70;r<400;r+=70){ctx.beginPath();ctx.ellipse(400,400,r,390,0,0,Math.PI*2);ctx.stroke();}
  for(let r=-300;r<=300;r+=100){ctx.beginPath();ctx.ellipse(400,400,390,Math.max(20,Math.sqrt(390*390-r*r)),0,0,Math.PI*2);ctx.stroke();}
  for(const p of globeDots){
    const lon=p.lon+rotation;
    const x=(lon+180)/360*800;
    const y=(90-p.lat)/180*800;
    const dx=x-400,dy=y-400;
    if(dx*dx+dy*dy>390*390)continue;
    const front=Math.max(.15,1-Math.abs(dx)/480);
    ctx.fillStyle=p.land?`rgba(104,233,255,${.68*front})`:`rgba(87,157,210,${.16*front})`;
    ctx.beginPath();ctx.arc(x,y,p.land?1.8:1,0,Math.PI*2);ctx.fill();
  }
  // luminous meridian and destination flare
  ctx.strokeStyle="rgba(95,245,255,.25)";
  ctx.beginPath();ctx.ellipse(400,400,100,390,rotation*.01,0,Math.PI*2);ctx.stroke();
  ctx.restore();
  rotation=(rotation+.035)%360;
  globeFrame=requestAnimationFrame(drawGlobe);
}
let globeFrame=requestAnimationFrame(drawGlobe);
addEventListener("resize",resizeGlobe);
resizeGlobe();

/* Scroll choreography: globe scales and card enters, then flips.
   No dependency on external animation libraries. */
const journey=$("#home");
const journeySection=$(".journey");
const holo=$("#holoCard");
const holoInner=$("#holoInner");
const hero=$("#heroCopy");
const cue=$("#scrollCue");
const coords=$("#coordinates");
const caption=$("#journeyCaption");
function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
let scrollFrame=false;
function animateJourney(){
  const sectionTop=journeySection.getBoundingClientRect().top;
  const scrollable=journeySection.offsetHeight-innerHeight;
  const p=clamp(-sectionTop/Math.max(1,scrollable),0,1);
  // zoom through a staged visual journey; intentionally not real map coordinates
  const zoom=1+Math.pow(clamp(p/.72,0,1),2)*4.8;
  const x=-p*8, y=-p*6;
  canvas.style.transform=`translate(calc(-50% + ${x}vw),calc(-50% + ${y}vh)) scale(${zoom})`;
  hero.style.opacity=String(1-clamp(p*2.3,0,1));
  cue.style.opacity=String(1-clamp(p*2.8,0,1));
  coords.style.opacity=String(clamp((p-.15)*2,0,1));
  const cardP=clamp((p-.43)/.43,0,1);
  holo.style.opacity=String(cardP);
  holo.style.transform=`translate(-50%,-50%) scale(${.78+.22*cardP})`;
  holoInner.style.transform=`rotateY(${cardP*180}deg) rotateX(${Math.sin(cardP*Math.PI)*4}deg)`;
  caption.style.opacity=String(clamp((p-.75)*4,0,1));
  scrollFrame=false;
}
function onScrollJourney(){if(!scrollFrame){requestAnimationFrame(animateJourney);scrollFrame=true;}}
addEventListener("scroll",onScrollJourney,{passive:true});
addEventListener("resize",animateJourney);
animateJourney();

/* Product category filter + live search */
let activeFilter="all";
const search=$("#productSearch");
const cards=$$(".product-card");
function filterProducts(){
  const q=search.value.trim().toLowerCase();
  let shown=0;
  cards.forEach(card=>{
    const matchesCategory=activeFilter==="all"||card.dataset.category===activeFilter;
    const matchesText=!q||(card.dataset.search+" "+card.innerText).toLowerCase().includes(q);
    const show=matchesCategory&&matchesText;
    card.hidden=!show;
    if(show)shown++;
  });
  $("#noResults").hidden=shown!==0;
}
$("#filters").addEventListener("click",e=>{
  const button=e.target.closest("[data-filter]");
  if(!button)return;
  activeFilter=button.dataset.filter;
  $$(".filter").forEach(b=>b.classList.toggle("active",b===button));
  filterProducts();
});
search.addEventListener("input",filterProducts);

/* Scroll reveal */
const revealObserver=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){entry.target.classList.add("in-view");revealObserver.unobserve(entry.target);}
  });
},{threshold:.1});
$$(".reveal").forEach(el=>revealObserver.observe(el));

/* Inquiry dialog: product buttons preselect product. */
const dialog=$("#inquiryDialog");
function openInquiry(item="General enquiry"){
  $("#enquiryProduct").value=item;
  if(typeof dialog.showModal==="function")dialog.showModal();
  else alert("Your browser does not support the enquiry dialog. Please contact the shop directly.");
}
$("#openInquiry").addEventListener("click",()=>openInquiry());
$("#contactButton").addEventListener("click",()=>openInquiry());
$$(".add-btn").forEach(btn=>btn.addEventListener("click",()=>openInquiry(btn.dataset.item)));
$("#sendEnquiry").addEventListener("click",()=>{
  const product=$("#enquiryProduct").value;
  const note=$("#enquiryMessage").value.trim();
  const message=`Hello New Prakash Radio Service! I'm enquiring about: ${product}.${note?" Message: "+note:""} Please share details and availability.`;
  if(!SHOP_WHATSAPP){
    alert("WhatsApp is not configured yet. In script.js, add your shop's WhatsApp number to SHOP_WHATSAPP (country code + number, digits only), then try again.");
    return;
  }
  const url="https://wa.me/"+SHOP_WHATSAPP+"?text="+encodeURIComponent(message);
  window.open(url,"_blank","noopener,noreferrer");
  dialog.close();
});

/* Product tilt is intentionally subtle and only for fine pointers. */
if(matchMedia("(pointer:fine)").matches){
  $$(".product-card").forEach(card=>{
    card.addEventListener("pointermove",e=>{
      const r=card.getBoundingClientRect();
      const rx=((e.clientY-r.top)/r.height-.5)*-4;
      const ry=((e.clientX-r.left)/r.width-.5)*4;
      card.style.transform=`translateY(-4px) perspective(800px) rotateX(${rx}deg) rotateY(${ry}deg)`;
    });
    card.addEventListener("pointerleave",()=>card.style.transform="");
  });
}
